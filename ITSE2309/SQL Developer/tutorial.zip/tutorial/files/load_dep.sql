INSERT INTO newtabl VALUES 
  ( 2, 'database', 'draft');

INSERT INTO dependents VALUES 
  ( 3, 'apex', 'reviewed');
        
INSERT INTO dependents VALUES 
  ( 4, 'rac', 'reviewed');

INSERT INTO dependents VALUES 
  ( 5, 'grid control', 'final');

INSERT INTO dependents VALUES 
  ( 6, 'streams', 'final');

INSERT INTO dependents VALUES 
  ( 7, 'osb', 'draft');

INSERT INTO dependents VALUES 
  ( 8, 'dataguard', 'final');

        
       
        
        