

REM ***************************insert data into the EMPLOYMENT_HISTORY table

INSERT INTO employment_history VALUES 
        ( 'Public Accountant'
        , 'Accounting'
        , 'Neena'
        , 'Kochhar'
        , TO_DATE('21-SEP-1989', 'dd-MON-yyyy')
        , TO_DATE('27-OCT-1993', 'dd-MON-yyyy')
        );
        
INSERT INTO employment_history VALUES 
        ( 'Accounting Manager'
        , 'Accounting'
        , 'Neena'
        , 'Kochhar'
        , TO_DATE('28-OCT-1993', 'dd-MON-yyyy')
        , TO_DATE('15-MAR-1998', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Programmer'
        , 'IT'
        , 'Lex'
        , 'De Haan'
        , TO_DATE('13-JAN-1994', 'dd-MON-yyyy')
        , TO_DATE('24-JUL-1998', 'dd-MON-yyyy')
        );
        
INSERT INTO employment_history VALUES 
        ( 'Stock Clerk'
        , 'Shipping'
        , 'Den'
        , 'Raphaely'
        , TO_DATE('24-MAR-1998', 'dd-MON-yyyy')
        , TO_DATE('31-DEC-1999', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Stock Clerk'
        , 'Shipping'
        , 'Payam'
        , 'Kaufling'
        , TO_DATE('01-JAN-1999', 'dd-MON-yyyy')
        , TO_DATE('31-DEC-1999', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Sales Representative'
        , 'Sales'
        , 'Jonathon'
        , 'Taylor'
        , TO_DATE('24-MAR-1998', 'dd-MON-yyyy')
        , TO_DATE('31-DEC-1998', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Sales Manager'
        , 'Sales'
        , 'Jonathon'
        , 'Taylor'
        , TO_DATE('01-JAN-1999', 'dd-MON-yyyy')
        , TO_DATE('31-DEC-1999', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Administrative Assistant'
        , 'Executive'
        , 'Jennifer'
        , 'Whalen'
        , TO_DATE('17-SEP-1987', 'dd-MON-yyyy')
        , TO_DATE('17-JUN-1993', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Public Accountant'
        , 'Executive'
        , 'Jennifer'
        , 'Whalen'
        , TO_DATE('01-JUL-1994', 'dd-MON-yyyy')
        , TO_DATE('31-DEC-1998', 'dd-MON-yyyy')
        );

INSERT INTO employment_history VALUES 
        ( 'Marketing Representative'
        , 'Marketing'
        , 'Michael'
        , 'Hartstein'
        , TO_DATE('17-FEB-1996', 'dd-MON-yyyy')
        , TO_DATE('19-DEC-1999', 'dd-MON-yyyy')
        );
