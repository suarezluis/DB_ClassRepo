
Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('MarK'	,     'Austin',	 '11-Nov-1995',	'Son',	'M',      105);


Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
values ('Mary'	,     'Austin',	 '14-Feb-1950',	'Spouse', 'F',	105);

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Sally',     'Urman',	 '5-Jun-1997',	'Daughter', 'F',	112);

commit;

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Billy',	     'Popp',	'13-Apr-1992',	'Son',	'M',	113);

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Mike', 'Matos',	'08-April-1997',  'Son', 'M',   143);

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Kim',      'Gee',  	'18-Jul-1972',	'Spouse', ' F',  135);

commit;

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Kelly',      'Gee',  	'12-June-1992',	'Daughter', 'F',  135);

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Pam',	     'Seo',	'21-aug-1965',    'Spouse', 'M', 139);

Insert into DEpendents
( FIRST_NAME,   LAST_NAME, BIRTHDATE,RELATION,GENDER,RELATIVE_ID)
 values ('Peggy',	     'Seo',	'11-Dec-2002',    'Daughter', 'F',  129);


Commit;