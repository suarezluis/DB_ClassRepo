Update dependentes 
Set benefits=
'Benefits Form

Beneficiary

Policy Number:  67890
Name: Mark	Smith	
Date of Birth: 14/02/1950	
Gender M:
Social Security Number: 444-67-9999


Benefits

Health care:  HMO
Vision: Yes
Dental: Yes
Life insurance 300,000
Accidental Death and Dismemberment: Declined'
Where  id= 5100;
