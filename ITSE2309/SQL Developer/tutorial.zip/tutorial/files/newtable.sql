INSERT INTO newtable VALUES 
  ( 2, 'database', 'draft',null);

INSERT INTO newtable VALUES 
  ( 3, 'apex', 'reviewed',null);
        
INSERT INTO newtable VALUES 
  ( 4, 'rac', 'reviewed',null);

INSERT INTO newtable VALUES 
  ( 5, 'grid control', 'final',null);

INSERT INTO newtable VALUES 
  ( 6, 'streams', 'final',null);

INSERT INTO newtable VALUES 
  ( 7, 'osb', 'draft',null);

INSERT INTO newtable VALUES 
  ( 8, 'dataguard', 'final',null);

        
       
        
        