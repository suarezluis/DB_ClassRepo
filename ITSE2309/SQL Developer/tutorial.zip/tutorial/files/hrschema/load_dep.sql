

REM ***************************insert data into the EMPLOYEES table

INSERT INTO dependents VALUES 
        ( 100
        , 'Sue'
        , 'Littlefield'
        , TO_DATE('17-JUN-1997', 'dd-MON-yyyy')
        , 'daughter'
        , 'F'
        , 201
        , NULL
        );

INSERT INTO dependents VALUES 
        ( 102
        , 'David'
        , 'Griffiths'
        , TO_DATE('2-APR-1999', 'dd-MON-yyyy')
        , 'son'
        , 'M'
        , 201
        , NULL
        );
        
   INSERT INTO dependents VALUES 
        ( 104
        , 'Jill'
        , 'Reed'
        , TO_DATE('10-FEB-1992', 'dd-MON-yyyy')
        , 'daughter'
        , 'F'
        , 119
        , NULL
        );
   
   INSERT INTO dependents VALUES 
        ( 106
        , 'Vicki'
        , 'Dean'
        , TO_DATE('19-AUG-2001', 'dd-MON-yyyy')
        , 'daughter'
        , 'F'
        , 208
        , NULL
        );
        
   INSERT INTO dependents VALUES 
        ( 108
        , 'Don'
        , 'King'
        , TO_DATE('24-OCT-1989', 'dd-MON-yyyy')
        , 'son'
        , 'M'
        , 120
        , NULL
        );
        
       
        
        